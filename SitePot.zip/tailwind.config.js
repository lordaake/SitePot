// tailwind.config.js

import typography from '@tailwindcss/typography';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'base-dark': 'hsl(228, 48%, 10%)',     // Rich Navy
                'base-light': 'hsl(228, 30%, 15%)',    // Lighter Navy for cards
                'base-mid': 'hsl(228, 35%, 12%)',      // Intermediate shade

                'text-primary': 'hsl(220, 20%, 94%)',  // Soft Off-White
                'text-secondary': 'hsl(220, 15%, 75%)', // Muted Gray
                'text-tertiary': 'hsl(220, 10%, 60%)',  // Softer Gray

                'accent-gold': 'hsl(45, 100%, 60%)',   // Vibrant Gold
                'accent-gold-dark': 'hsl(40, 90%, 50%)',

                'accent-teal': 'hsl(170, 70%, 55%)',   // Mystic Teal
                'accent-teal-dark': 'hsl(170, 60%, 45%)',

                'accent-pink': 'hsl(320, 60%, 70%)',   // Arcane Pink
                'accent-pink-dark': 'hsl(320, 50%, 60%)',
            },
            backgroundImage: {
                'magic-bg': 'radial-gradient(circle at 15% 85%, hsla(320, 60%, 70%, 0.1) 0%, transparent 30%), radial-gradient(circle at 85% 20%, hsla(170, 70%, 55%, 0.1) 0%, transparent 35%)',
            },
            boxShadow: {
                'soft-glow': '0 0 25px -5px var(--glow-color, hsl(45 100% 60% / 0.5))',
                'card-shadow': '0 4px 20px -2px rgba(0, 0, 0, 0.4)',
            },
            keyframes: {
                float: {
                    '0%, 100%': { transform: 'translateY(0px)' },
                    '50%': { transform: 'translateY(-10px)' },
                },
                'spin-slow': {
                    from: { transform: 'rotate(0deg)' },
                    to: { transform: 'rotate(360deg)' },
                },
                'glow-pulse': {
                    '0%, 100%': { opacity: '1', filter: 'brightness(1.1)' },
                    '50%': { opacity: '0.8', filter: 'brightness(1)' },
                }
            },
            animation: {
                'float': 'float 5s ease-in-out infinite',
                'spin-slow': 'spin-slow 30s linear infinite',
                'glow-pulse': 'glow-pulse 3s ease-in-out infinite',
            },
        },
    },
    plugins: [
        typography,
    ],
}