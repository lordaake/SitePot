// src/components/DomainList.jsx

import { useState, useMemo } from 'react';
import { Search, Filter } from 'lucide-react';
import { domains, categories } from '../data/domains';
import DomainCard from './DomainCard';

function DomainList() {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('All Categories');

    const filteredDomains = useMemo(() => {
        let filtered = domains;
        if (selectedCategory !== 'All Categories') {
            filtered = filtered.filter(d => Array.isArray(d.category) ? d.category.includes(selectedCategory) : d.category === selectedCategory);
        }
        if (searchTerm) {
            filtered = filtered.filter(d => d.name.toLowerCase().includes(searchTerm.toLowerCase()) || d.description.toLowerCase().includes(searchTerm.toLowerCase()));
        }
        const xyz = filtered.filter(d => d.name.endsWith('.xyz')).sort((a, b) => a.name.localeCompare(b.name));
        const nonXyz = filtered.filter(d => !d.name.endsWith('.xyz')).sort((a, b) => a.name.localeCompare(b.name));
        return [...nonXyz, ...xyz];
    }, [searchTerm, selectedCategory]);

    return (
        <section id="domains" className="py-16">
            <h2 className="text-4xl font-bold text-text-primary mb-8 border-b-2 border-accent-gold inline-block pb-2">Explore Our Brew</h2>
            <div className="flex flex-col sm:flex-row gap-6 mb-8 items-center justify-between">
                <div className="relative w-full sm:w-2/3">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-accent-teal w-6 h-6" />
                    <input
                        type="text"
                        placeholder="Search for a domain spell..."
                        className="w-full pl-14 pr-4 py-3 bg-base-mid border border-white/10 text-text-primary rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-accent-gold placeholder-text-tertiary"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <div className="relative w-full sm:w-1/3">
                    <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-accent-pink w-6 h-6" />
                    <select
                        className="appearance-none w-full pl-14 pr-4 py-3 bg-base-mid border border-white/10 text-text-primary rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-accent-gold"
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                    >
                        <option value="All Categories">All Categories</option>
                        {categories.map(category => (<option key={category} value={category}>{category}</option>))}
                    </select>
                </div>
            </div>
            <p className="text-accent-gold mb-8 font-bold tracking-wider">{filteredDomains.length} enchanted domains found</p>
            {filteredDomains.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredDomains.map(domain => (<DomainCard key={domain.name} domain={domain} />))}
                </div>
            ) : (
                <div className="text-center py-16">
                    <p className="text-2xl text-text-secondary font-semibold">No domains found matching your incantation.</p>
                </div>
            )}
        </section>
    );
}

export default DomainList;
