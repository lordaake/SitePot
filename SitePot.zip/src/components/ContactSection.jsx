// src/components/ContactSection.jsx

function ContactSection() {
    return (
        <section id="contact" className="bg-base-light rounded-2xl max-w-3xl mx-auto p-12 text-center border border-accent-orange/20 mt-24">
            <h2 className="text-4xl font-extrabold text-text-primary mb-4">Ready to Own Your Magic Name?</h2>
            <p className="text-lg text-text-secondary mb-8 max-w-xl mx-auto">
                Each domain is a gateway to opportunity. Click on any domain to visit its page and make an offer directly. For general inquiries, feel free to reach out.
            </p>
            <a
                href="mailto:ramlarssondigital@proton.me"
                className="inline-block bg-accent-orange text-base-dark font-medium rounded-lg px-10 py-4 shadow-sm hover:shadow-soft-glow hover:scale-105 transform transition duration-300"
            >
                Contact Us
            </a>
        </section>
    );
}

export default ContactSection;
