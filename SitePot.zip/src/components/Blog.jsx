// src/components/Blog.jsx

import { Calendar, Clock, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { blogPosts } from '../data/blogData'; // Correct import path

function Blog() {
  return (
    <div className="container mx-auto px-4 py-12">
      <section className="text-center mb-16">
        <h2 className="text-5xl font-extrabold text-neon-pink mb-4 drop-shadow-[0_0_8px_rgba(255,170,255,0.7)]">
          Domain Insights
        </h2>
        <p className="text-xl text-neon-green/90 max-w-3xl mx-auto">
          Expert strategies, trends, and tutorials for choosing, investing in, and maximizing the value of premium domains.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogPosts.map(post => (
          <div key={post.id} className="bg-black/40 rounded-2xl shadow-lg shadow-purple-900/40 hover:shadow-neon-pink/30 transition-all duration-300 overflow-hidden border border-neon-pink/20 flex flex-col hover:-translate-y-1">
            <img src={post.image} alt={post.title} className="w-full h-48 object-cover" />
            <div className="p-6 flex flex-col flex-grow">
              <span className="bg-neon-pink/20 text-neon-pink text-xs font-semibold px-3 py-1 rounded-full mb-4 self-start">
                {post.category}
              </span>
              <h3 className="text-xl font-bold text-yellow-300 mb-3 flex-grow">{post.title}</h3>
              <div className="flex items-center text-neon-green/70 text-sm mt-auto mb-4">
                <Calendar className="w-4 h-4 mr-1.5" /> {post.date}
                <Clock className="w-4 h-4 ml-4 mr-1.5" /> {post.readTime}
              </div>
              <p className="text-neon-green/80 text-sm mb-6 h-20 overflow-hidden text-ellipsis">
                {post.content[0].text.substring(0, 120)}...
              </p>
              <Link to={`/blog/${post.id}`} className="mt-auto inline-flex items-center text-neon-orange hover:text-yellow-300 font-bold self-start">
                Read More <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}

export default Blog;